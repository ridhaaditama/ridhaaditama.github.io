const mongoose = require("mongoose"),
	  passportLocalMongoose = require("passport-local-mongoose");

const userSchema = new mongoose.Schema({
	id: {
			type: mongoose.Schema.Types.ObjectId,
			ref: "User"
		},
	username: String,
	password: String,
	avatar: String,
	firstName: String,
	lastName: String,
	email: String
});

userSchema.plugin(passportLocalMongoose);

module.exports = mongoose.model("User", userSchema);