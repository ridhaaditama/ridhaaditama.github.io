const mongoose = require("mongoose"),
	  Blog = require("./models/blogsite"),
	  Comment = require("./models/comment");

var data = [
	{
		title: "First Blog",
		image: "https://images.unsplash.com/photo-1556909172-8c2f041fca1e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
		body: "Lorem ipsum dolor sit amet, vitae utamur persequeris pri ad, falli option epicuri eum et. Case electram ad mel, duo id feugiat theophrastus. Ut clita tempor eum, eu vel harum intellegebat. Usu et salutandi percipitur, qualisque adolescens at nec.",
	},
	{
		title: "Second Blog",
		image: "https://images.unsplash.com/photo-1562101806-6a5f9ec69f41?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
		body: "Lorem ipsum dolor sit amet, vitae utamur persequeris pri ad, falli option epicuri eum et. Case electram ad mel, duo id feugiat theophrastus. Ut clita tempor eum, eu vel harum intellegebat. Usu et salutandi percipitur, qualisque adolescens at nec.",
	},
	{
		title: "Third Blog",
		image: "https://images.unsplash.com/photo-1563387920443-6f3171e4793b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
		body: "Lorem ipsum dolor sit amet, vitae utamur persequeris pri ad, falli option epicuri eum et. Case electram ad mel, duo id feugiat theophrastus. Ut clita tempor eum, eu vel harum intellegebat. Usu et salutandi percipitur, qualisque adolescens at nec.",
	}
];

function seedDB(){
	// REMOVE ALL BLOGS
	Blog.remove({}, function(err){
		if(err){
			console.log(err);
		} else {
			console.log("Removed Blogs");
			// CREATE SOME BLOGS
			data.forEach(function(seed){
				Blog.create(seed, function(err, blog){
					if(err){
						console.log(err);
					} else {
						console.log("Added a Blog");
						// create a comment
						Comment.create({
							text: "This is great",
							author: "Harry Potter"
						}, function(err, comment){
							if(err){
								console.log(err);
							} else {
								console.log("Created new comment");
								blog.comments.push(comment);
								blog.save();	
							}
						});
					}
				});
			});
		}
	});
}

module.exports = seedDB;