const express = require("express"),
	  router = express.Router(),
	  Blog = require("../models/blogsite"),
	  middleware = require("../middleware/blog");


//INDEX
router.get("/", function(req, res){
	Blog.find({}, function(err, blogs){
		if(err){
			console.log(err);
		} else {
			res.render("blogsite/index", {blogs: blogs});	
		}
	});
});
//NEW
router.get("/new", middleware.isLoggedIn, function(req, res){
	res.render("blogsite/new");
});
//CREATE
router.post("/", middleware.isLoggedIn, function(req, res){
	var title = req.body.blog.title;
	var image = req.body.blog.image;
	var body = req.body.blog.body;
	var created = req.body.blog.created;
	var author = {
		id: req.user._id,
		username: req.user.username
	};
	var newBlog = {title: title, image:image, body:body, author: author, created: created};
	Blog.create(newBlog, function(err, newlyCreated){
		if(err){
			res.render("blogsite/new");
		} else {
			res.redirect("/blogsite");
		}
	});
});
//SHOW
router.get("/:id", function(req, res){
	Blog.findById(req.params.id).populate("comments").exec(function(err, foundBlog){
		if(err){
			res.redirect("/blogsite");
		} else {
			res.render("blogsite/show", {blog: foundBlog});
		}
	});
});
//EDIT
router.get("/:id/edit", middleware.checkBlogOwnership, function(req, res){
	Blog.findById(req.params.id, function(err, foundBlog){
		res.render("blogsite/edit", {blog: foundBlog});	
	});
});
//UPDATE
router.put("/:id", middleware.checkBlogOwnership, function(req, res){
	req.body.blog.body = req.sanitize(req.body.blog.body);
	Blog.findByIdAndUpdate(req.params.id, req.body.blog, function(err, updatedBlog){
		if(err){
			res.redirect("/blogsite");
		} else {
			res.redirect("/blogsite/" + req.params.id);
		}
	});
});
//DELETE
router.delete("/:id", middleware.checkBlogOwnership, function(req, res){
	Blog.findByIdAndRemove(req.params.id, function(err){
		if(err){
			res.redirect("/blogsite");
		} else{
			res.redirect("/blogsite");
		}
	});
});


module.exports = router;