const express = require("express"),
	  app = express(),
	  bodyParser = require("body-parser"),
	  mongoose = require("mongoose"),
	  expressSanitizer = require("express-sanitizer"),
	  passport = require("passport"),
	  localStrategy = require("passport-local"),
	  flash = require("connect-flash"),
	  session = require("express-session"),
	  methodOverride = require("method-override"),
	  seedDB = require("./seeds"),
	  Blog = require("./models/blogsite"),
	  User = require("./models/user"),
	  Comment = require("./models/comment");

//Requiring Routes
const blogRoutes = require("./routes/blogsite"),
	  commentRoutes = require("./routes/comments"),
	  indexRoutes = require("./routes/index");

// seedDB();
// APP CONFIG
mongoose.connect("mongodb://localhost/blog_app", {useNewUrlParser: true, useCreateIndex: true}); // to connect to database
app.set("view engine", "ejs"); //look for the document ".ejs"
app.use(express.static(__dirname + "/public")); // for using css
app.use(bodyParser.urlencoded({extended: true}));
app.use(expressSanitizer());
app.use(methodOverride("_method"));

app.locals.moment = require('moment');
//Passport CONFIG
app.use(require("express-session")({
	secret: "Secret passport CONFIG",
	resave: false,
	saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());
passport.use(new localStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

//Pass something to all the templates
app.use(function(req, res, next){
	res.locals.currentUser = req.user;
	next();
});
// Use the routes templates
app.use("/", indexRoutes);
app.use("/blogsite", blogRoutes);
app.use("/blogsite/:id/comments", commentRoutes);

var port = process.env.PORT || 3000;
app.listen(port, function () {
    console.log("Server Has Started!");
});